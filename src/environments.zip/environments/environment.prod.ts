export const environment = {
    production: true,
    api:'http://10.3.65.243:8080',
    googleAuth:'https://backend-services.ru.ac.th/ru-smart-api/google/authorization'
  };